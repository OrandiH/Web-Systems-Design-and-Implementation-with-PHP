<!--Index page-->
<!--Programmer:Orandi Harris 1401374-->
<!DOCTYPE html>
<html>
<head>
	<title>Karisma</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body class="main">
	<center><p><h2>Click the link below to make your booking!</h2></p></center>
	<center><button><a href="Booking.php">Book your stay here</a></button></center>
</body>
</html>